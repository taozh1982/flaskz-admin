## 关于

常用功能扩展，按需使用

| Package               | Description                           |
| --------------------- | ------------------------------------- |
| [redis_ws](./redis_ws/README.md) | websockets + redis实现的消息广播功能 |
| [ncs](ncs/README.md) | NCS(配置下发)功能扩展 |
| [auth](./auth/README.md) | 第三方授权认证 |
| [swagger](./swagger/README.md) | Swagger文档 |

