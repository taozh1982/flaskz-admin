import time
from telnetlib import Telnet as telnetlib_Telnet


class Telnet():
    def __init__(self, hostname, username, password=None, port=23, **kwargs):

        self._hostname = hostname
        self._username = username
        self._password = password
        self._port = port
        self._secondary_password = kwargs.pop('secondary_password', None)  # for enable/sudo
        # recv_endswith = kwargs.pop('recv_endswith', None)  # for stop receiving
        self.recv_endswith = tuple(kwargs.pop('recv_endswith', None) or ['# ', '$ ', ': ', '? '])  # for stop receiving
        self.recv_start_delay = kwargs.pop('recv_start_delay', 0.1)  # @2023-12-31 add, delay before receiving data start
        if 'timeout' in kwargs:
            self._timeout = kwargs.pop('timeout', 0)
        else:
            self._timeout = 10

        if hostname is None and 'host' in kwargs:
            self._hostname = kwargs.pop('host', None)

    def telnet(self):
        if not hasattr(self, '_telnet'):
            self._telnet = telnetlib_Telnet(self._hostname, self._port, timeout=self._timeout)  # @2023-10-31 add width
            # print(self._telnet.read_all())
            # print(self._telnet.read_until(b"Username: "))
            print(self._recv_data())

        return self._telnet

    # def _run_command(self, command, recv=True, prompt=None):
    #
    #     _command = command.strip()
    #     self.telnet.send(_command + '\n')
    #     if recv is False:
    #         return None
    #     output = self._recv_data(prompt)
    #     return output

    def _recv_data(self):
        # 等待一段时间，以确保命令执行完成
        time.sleep(3)
        # 读取命令的执行结果
        # return self._telnet.read_some()
        output = self._telnet.read_very_eager()#.decode('ascii')
        return output

#
# telnet = Telnet('10.124.205.73', 'cisco', '1qaz@WSX')
# telnet.telnet()
# Telnet服务器的IP地址和端口
HOST = "10.124.205.73"
PORT = 23

# 要发送的命令
COMMAND = "show interface all"

# 创建一个Telnet客户端对象
tn = telnetlib_Telnet(HOST, PORT)

# 等待登录提示
tn.read_until(b"Username: ")

# 输入用户名和密码（如果需要）
tn.write(b"cisco\n")
tn.read_until(b"Password: ")
tn.write(b"1qaz@WSX\n")

# 等待命令提示符
tn.read_until(b"#")

# 发送命令
tn.write(COMMAND.encode('ascii') + b"\n")

# 等待一段时间，以确保命令执行完成
time.sleep(2)

# 读取命令的执行结果
# output = tn.read_very_eager().decode('ascii')
# print(output)

chunk_size = 1024

data = b""
chunk = tn.read_some()  # 初次读取

while chunk:
    data += chunk
    if len(chunk) < 1:
        break  # 如果读取的数据少于chunk_size，假设数据已经读取完毕
    chunk = tn.read_some()

# 将收到的字节数据解码为字符串（如果需要的话）
data_str = data.decode('ascii')  # 或者使用服务器的编码方式

print(data_str)